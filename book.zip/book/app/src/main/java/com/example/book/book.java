package com.example.book;

public class book {
    //Attribute
    String name;
    String category;
    String author;

    void read(){
        System.out.println("read");
    }
}
